package com.medicare.claims;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/api/claims")
public class ClaimsController {

    private final GenAIXmlGenerator xmlGenerator = new GenAIXmlGenerator();

    @PostMapping(value = "/generate", produces = MediaType.APPLICATION_XML_VALUE)
    public String generate(@RequestBody Map<String, String> membershipInput) throws IOException {
        String requirementContent = StreamUtils.copyToString(
                new ClassPathResource("sample_requirement.txt").getInputStream(),
                StandardCharsets.UTF_8
        );
        String generatedXml = xmlGenerator.generateXmlFromContent(requirementContent, membershipInput);
        return generatedXml;
    }

    @GetMapping(value = "/sample", produces = MediaType.APPLICATION_XML_VALUE)
    public String sample() throws IOException {
        return StreamUtils.copyToString(
                new ClassPathResource("sample_medicare_claim.xml").getInputStream(),
                StandardCharsets.UTF_8
        );
    }
} 