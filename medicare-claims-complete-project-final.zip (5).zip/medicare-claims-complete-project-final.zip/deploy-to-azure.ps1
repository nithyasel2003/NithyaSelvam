# Medicare Claims Azure Deployment Script
# This script deploys the Medicare Claims project to Azure App Service

param(
    [Parameter(Mandatory=$true)]
    [string]$AppName,
    
    [string]$ResourceGroup = "medicare-rg",
    [string]$ServicePlan = "medicare-plan",
    [string]$Location = "eastus"
)

Write-Host "🏥 Medicare Claims - Azure Deployment" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Validate app name
if ($AppName -notmatch '^[a-zA-Z0-9-]+$') {
    Write-Error "App name must contain only letters, numbers, and hyphens"
    exit 1
}

Write-Host "App Name: $AppName" -ForegroundColor Green
Write-Host "Resource Group: $ResourceGroup" -ForegroundColor Green
Write-Host "Location: $Location" -ForegroundColor Green

# Check if Azure CLI is installed
try {
    az --version | Out-Null
    Write-Host "✅ Azure CLI detected" -ForegroundColor Green
} catch {
    Write-Error "❌ Azure CLI not found. Please install from: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
    exit 1
}

# Check if logged in
try {
    $account = az account show --query "name" -o tsv 2>$null
    if ($account) {
        Write-Host "✅ Logged in to Azure as: $account" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Not logged in to Azure. Running az login..." -ForegroundColor Yellow
        az login
    }
} catch {
    Write-Host "⚠️  Not logged in to Azure. Running az login..." -ForegroundColor Yellow
    az login
}

Write-Host "`n🚀 Starting deployment..." -ForegroundColor Yellow

# Step 1: Create Resource Group
Write-Host "📦 Creating resource group..." -ForegroundColor Blue
az group create --name $ResourceGroup --location $Location --output table

# Step 2: Create App Service Plan
Write-Host "📋 Creating App Service plan..." -ForegroundColor Blue
az appservice plan create --name $ServicePlan --resource-group $ResourceGroup --sku B1 --is-linux --output table

# Step 3: Create Web App
Write-Host "🌐 Creating web app..." -ForegroundColor Blue
az webapp create --name $AppName --resource-group $ResourceGroup --plan $ServicePlan --runtime "JAVA:17-java17" --output table

# Step 4: Configure App Settings
Write-Host "⚙️  Configuring app settings..." -ForegroundColor Blue
az webapp config appsettings set --name $AppName --resource-group $ResourceGroup --settings SCM_DO_BUILD_DURING_DEPLOYMENT=true WEBSITES_PORT=8080 --output table

# Step 5: Deploy Application
Write-Host "📤 Deploying application..." -ForegroundColor Blue
Write-Host "This may take several minutes as Azure builds your Java application..." -ForegroundColor Yellow
az webapp deploy --name $AppName --resource-group $ResourceGroup --type zip --src-path .

# Step 6: Get URL
$webUrl = "https://$AppName.azurewebsites.net"
Write-Host "`n🎉 Deployment completed!" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Your Medicare Claims app is now live at:" -ForegroundColor Green
Write-Host "$webUrl" -ForegroundColor Cyan

Write-Host "`n📋 Available Endpoints:" -ForegroundColor Yellow
Write-Host "Sample XML: $webUrl/api/claims/sample" -ForegroundColor White
Write-Host "Generate XML: POST $webUrl/api/claims/generate" -ForegroundColor White

Write-Host "`n🧪 Test Commands:" -ForegroundColor Yellow
Write-Host "# Test sample endpoint" -ForegroundColor Gray
Write-Host "curl '$webUrl/api/claims/sample'" -ForegroundColor White

Write-Host "`n# Test generate endpoint" -ForegroundColor Gray
Write-Host @"
curl -X POST '$webUrl/api/claims/generate' \
  -H 'Content-Type: application/json' \
  -d '{
    "memberId": "MBR999888777",
    "medicareId": "9ZX8YW7VU65",
    "firstName": "Alice",
    "lastName": "Johnson",
    "dateOfBirth": "1948-12-10",
    "gender": "F",
    "street": "456 Elm Street",
    "city": "Springfield",
    "state": "NY",
    "zipCode": "12345",
    "planType": "Medicare Part A",
    "serviceDate": "2024-01-15"
}'
"@ -ForegroundColor White

Write-Host "`n💡 Management:" -ForegroundColor Yellow
Write-Host "Azure Portal: https://portal.azure.com" -ForegroundColor White
Write-Host "Logs: az webapp log tail --name $AppName --resource-group $ResourceGroup" -ForegroundColor White
Write-Host "Delete: az group delete --name $ResourceGroup --yes" -ForegroundColor White 